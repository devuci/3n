aux variable = Group-averaged values of the optimal value of the functional J

First dimension = number of subjects
Second dimension = number of considered modalities (MST PMFG, MST+ECO, ECO)

%%%

Delta variable = Values of distance between the optimal functional values J across modalities

First dimension = number of considered modalities (MST PMFG, MST+ECO, ECO)
Second dimension = number of possible comparisons between subjects (= (N diseased + N healthy)^2)

%%%

EEG
N diseased = 20
N healthy = 20

fMRI
N diseased = 17
N healthy = 17

MEG
N diseased = 5
N healthy = 5

DTI
N diseased = 19
N healthy = 19