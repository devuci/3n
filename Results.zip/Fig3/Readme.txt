Size of the giant component

First dimension = number of groups (diseased, healthy)
Second dimension = number of subjects per group
Third dimension = threshold value (in terms of average node degree k=1, 2, .., max nodes -1)