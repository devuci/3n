x=number of nodes
D=optimal density derived from ECO